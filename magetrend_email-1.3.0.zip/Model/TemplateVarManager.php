<?php
/**
 * Copyright © 2016 MB Vienas bitas. All rights reserved.
 * @website    www.magetrend.com
 * @package    MT Email for M2
 * @author     Edvinas Stulpinas <edwin@magetrend.com>
 */

namespace Magetrend\Email\Model;

class TemplateVarManager extends \Magento\Framework\DataObject
{
    private $vars = [];

    private $isCollected = false;

    /**
     * @var \Magento\Framework\Event\Manager
     */
    public $eventManager;

    /**
     * @var \Magento\Framework\DataObjectFactory
     */
    public $dataObjectFactory;

    /**
     * @var \Magento\Framework\Filesystem\Directory\ReadFactory
     */
    public $readFactory;

    public $moduleReader;

    public $fileDriver;

    public $layout;

    /**
     * TemplateVarManager constructor.
     * @param \Magento\Framework\Event\Manager $eventManager
     * @param \Magento\Framework\Filesystem\Directory\ReadFactory $readFactory
     */
    public function __construct(
        \Magento\Framework\Event\Manager $eventManager,
        \Magento\Framework\Filesystem\Directory\ReadFactory $readFactory,
        \Magento\Framework\Module\Dir\Reader $moduleReader,
        \Magento\Framework\Filesystem\Driver\File $fileDriver,
        \Magento\Framework\View\LayoutInterface $layout
    ) {
        $this->eventManager = $eventManager;
        $this->readFactory = $readFactory;
        $this->moduleReader = $moduleReader;
        $this->fileDriver = $fileDriver;
        $this->layout = $layout;
    }

    public function reset()
    {
        $this->vars = [];
        $this->setData([]);
    }

    public function setVariables($vars)
    {
        $this->vars = $vars;

        return $this;
    }

    public function getData($key = '', $index = null)
    {
        if ($this->isCollected === false) {
            $this->collect();
            $this->isCollected = true;
        }

        return parent::getData($key, $index);
    }

    public function collect()
    {
        $this->eventManager->dispatch('magetrend_email_collect_additional_vars', [
            'vars' => $this->vars,
            'additional_vars' => $this,
        ]);
    }

    public function getDesignCss($template)
    {
        $origTemplateCode = $template->getOrigTemplateCode();
        if (strpos($origTemplateCode, 'mt_email_') === false) {
            return '';
        }

        $theme = explode('_', $origTemplateCode);
        $theme = $theme[2];

        $cssPath = $this->moduleReader->getModuleDir(
            \Magento\Framework\Module\Dir::MODULE_VIEW_DIR,
            'Magetrend_Email'
        ).'/frontend/web/css/email/';

        if (!$this->fileDriver->isExists($cssPath.$theme.'.css')) {
            return '';
        }
         $fileContent = $this->readFactory->create($cssPath)
             ->readFile($theme.'.css');

        return $fileContent;
    }

    public function getDesignHeadHtml($template)
    {
        $designName = $this->getDesignName($template);
        if (empty($designName)) {
            return '';
        }

        $block = $this->layout->createBlock(
            \Magento\Framework\View\Element\Template::class,
            'email_head'.rand(0, 9999).'_'.microtime()
        )
            ->setArea('frontend')
            ->setEditMode(true)
            ->setTemplate('Magetrend_Email::email/'.$designName.'/head.phtml');

        return $block->toHtml();
    }

    public function getDesignName($template)
    {
        if (!$template || !$template->getId()) {
            return '';
        }

        $origTemplateCode = $template->getOrigTemplateCode();
        if (strpos($origTemplateCode, 'mt_email_') === false) {
            return '';
        }

        $theme = explode('_', $origTemplateCode);
        $theme = $theme[2];

        return $theme;
    }

    public function getTrackingLink($shipment)
    {
        foreach ($shipment->getAllTracks() as $item) {
            return $this->getTrackinkLinkByItem($item);
        }
    }

    public function getTrackinkLinkByItem($item)
    {
        $trackurl = '';
        if ($item->getCarrierCode() === 'fedex') {
            $trackurl = 'https://www.fedex.com/apps/fedextrack/?action=track&trackingnumber='.$item->getNumber();
        } elseif ($item->getCarrierCode() === 'usps') {
            $trackurl = 'https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1='.$item->getNumber();
        } elseif ($item->getCarrierCode() === 'ups') {
            $trackurl = 'https://wwwapps.ups.com/WebTracking/returnToDetails?tracknum='.$item->getNumber();
        }

        return $trackurl;
    }

    public function getTrackingCode($shipment)
    {
        foreach ($shipment->getAllTracks() as $item) {
            return $item->getNumber();
        }
    }

    public function getTrack($shipment)
    {
        foreach ($shipment->getAllTracks() as $item) {
            return $item;
        }
    }

}
