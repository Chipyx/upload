<?php
namespace QualityUnit\PostAffiliatePro\Block\Adminhtml\System\Config\Fieldset;

use Magento\Framework\Data\Form\Element\AbstractElement;

class Expanded extends \Magento\Config\Block\System\Config\Form\Fieldset {

    // fieldset collapsed by default
    protected $isCollapsedDefault = true;
}