<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */

declare(strict_types=1);

namespace Amasty\Paction\Model\Command;

use Amasty\Paction\Helper\Data;
use Magento\Catalog\Model\Product;
use Magento\Eav\Model\Config;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\ObjectManagerInterface;
use Magento\Store\Model\StoreManagerInterface;

class Addprice extends Modifyprice
{
    public function __construct(
        Data $helper,
        ObjectManagerInterface $objectManager,
        Config $eavConfig,
        StoreManagerInterface $storeManager,
        ResourceConnection $resource
    ) {
        parent::__construct($helper, $objectManager, $eavConfig, $storeManager, $resource);

        $this->_type = 'addprice';
        $this->_info = array_merge($this->_info, [
            'confirm_title' => 'Modify Price using Cost',
            'confirm_message' => 'Are you sure you want to modify price using cost?',
            'type' => $this->_type,
            'label' => 'Modify Price using Cost'
        ]);
    }
    
    protected function _prepareQuery($table, $value, $where)
    {
        $where[] = 't.`value` > 0 ';
        $id = $attribute = $this->eavConfig
            ->getAttribute(Product::ENTITY, 'price')
            ->getAttributeId();
        $entityIdName = $this->helper->getEntityNameDependOnEdition();
            
        $value = str_replace('`value`', 't.`value`', $value);
        // phpcs:ignore: Magento2.SQL.RawQuery.FoundRawSql
        $sql = "INSERT INTO $table (attribute_id , store_id, $entityIdName, `value`) "
             . " SELECT $id, store_id, $entityIdName, $value FROM $table AS t"
             . " WHERE " . join(' AND ', $where)
             . " ON DUPLICATE KEY UPDATE `value` = $value";

        return $sql;
    }
    
    protected function _getAttrCode()
    {
        return 'cost';
    }
}
