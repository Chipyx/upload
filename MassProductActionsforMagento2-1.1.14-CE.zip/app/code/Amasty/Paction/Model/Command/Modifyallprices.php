<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */

declare(strict_types=1);

namespace Amasty\Paction\Model\Command;

use Amasty\Paction\Helper\Data;
use Amasty\Paction\Model\Command;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory;
use Magento\Eav\Model\Config;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Phrase;
use Magento\Store\Model\StoreManagerInterface;

class Modifyallprices extends Command
{
    protected $_priceCodes = [];

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var Config
     */
    protected $eavConfig;

    /**
     * @var AdapterInterface
     */
    protected $connection;

    public function __construct(
        CollectionFactory $collectionFactory,
        ResourceConnection $resource,
        StoreManagerInterface $storeManager,
        Data $helper,
        Config $eavConfig
    ) {
        parent::__construct();
        $this->collectionFactory = $collectionFactory;
        $this->resource = $resource;
        $this->connection = $resource->getConnection();
        $this->storeManager = $storeManager;
        $this->helper = $helper;
        $this->eavConfig = $eavConfig;

        $this->_type = 'modifyallprices';
        $this->_info = [
            'confirm_title' => __('Update All Types of Price')->__toString(),
            'confirm_message' => __('Are you sure you want to update all types of price?')->__toString(),
            'type' => $this->_type,
            'label' => __('Update All Types of Price')->__toString(),
            'fieldLabel' => __('By')->__toString(),
            'placeholder' => __('+12.5, -12.5, +12.5%')->__toString()
        ];
    }

    public function execute(array $ids, int $storeId, string $val): Phrase
    {
        if (!preg_match('/^[+-][0-9]+(\.[0-9]+)?%?$/', $val)) {
            throw new LocalizedException(__('Please provide the difference as +12.5, -12.5, +12.5% or -12.5%'));
        }
        $sign = substr($val, 0, 1);
        $val = substr($val, 1);
        $percent = ('%' == substr($val, -1, 1));

        if ($percent) {
            $val = (float)substr($val, 0, -1);
        }

        if ($val < 0.00001) {
            throw new LocalizedException(__('Please provide a non empty difference'));
        }

        if (!$this->_priceCodes) {
            $attributes = $this->collectionFactory->create()
                ->addVisibleFilter()
                ->addFieldToFilter('frontend_input', 'price');
            $priceCodes = [];

            foreach ($attributes as $attribute) {
                $priceCodes[$attribute->getId()] = $attribute->getAttributeCode();
            }
            $this->_priceCodes = $priceCodes;
        }

        $this->_updateAttributes($ids, $storeId, ['sign' => $sign, 'val' => $val, 'percent' => $percent]);
        //TODO change indexer status
        return __('Total of %1 products(s) have been successfully updated', count($ids));
    }

    protected function _updateAttributes(array $productIds, int $storeId, array $diff)
    {
        $attribute =  $this->eavConfig->getAttribute('catalog_product', 'price');
        $db = $this->connection;
        $table = $attribute->getBackend()->getTable();
        $entityIdName = $this->helper->getEntityNameDependOnEdition();

        $where = [
            $db->quoteInto($entityIdName . ' IN(?)', $productIds),
            $db->quoteInto('attribute_id IN(?)', array_keys($this->_priceCodes))
        ];

        $value = $diff['percent'] ? '`value` * ' . $diff['val'] . '/ 100' : $diff['val'];
        $value = '`value`' . $diff['sign'] . $value;

        if ('fixed' == $this->helper->getModuleConfig('general/round', $storeId)) {
            $fixed = $this->helper->getModuleConfig('general/fixed', $storeId);
            if (!empty($fixed)) {
                $fixed = floatval($fixed);
                $value = 'FLOOR(' . $value . ') + ' . $fixed;
            }
        } else { // math
            $value = 'ROUND(' . $value . ',2)'; // probably we will need change 2 to additional setting
        }

        $defaultStoreId = $this->storeManager->getDefaultStoreView()->getId();
        if ($storeId
            && $defaultStoreId != $storeId) {
            $storeIds = $this->storeManager->getStore($storeId)->getWebsite()->getStoreIds(true);
            $where[] = $db->quoteInto('store_id IN(?)', $storeIds);
        } else { // all stores
            $storeIds = [];
            $stores = $this->storeManager->getStores(true);

            foreach ($stores as $store) {
                $storeIds[] = $store->getId();
            }
            $where[] = $db->quoteInto('store_id IN(?)', $storeIds);
        }

        $where[] = 'value IS NOT NULL';

        // update all price attributes
        $sql = $this->_prepareQuery($table, $value, $where);
        $db->query($sql);

        // update group prices
       /* $table = $this->resource->getTableName('catalog_product_entity_group_price');
        $sql = $this->_prepareQuery($table, $value, $where);
        $db->query($sql);

        // update tier prices
        $table = $this->resource->getTableName('catalog_product_entity_tier_price');
        $sql = $this->_prepareQuery($table, $value, $where);
        $db->query($sql);
       */

        //update tier price
        $websiteId = $this->storeManager->getStore($storeId)->getWebsite()->getId();
        $where = [
            $db->quoteInto($entityIdName . ' IN(?)', $productIds),
            $db->quoteInto('website_id = ?', $websiteId)
        ];
        $table =  $this->resource->getTableName('catalog_product_entity_tier_price');
        $sql = $this->_prepareQuery($table, $value, $where);
        $db->query($sql);
    }

    protected function _prepareQuery($table, $value, $where)
    {
        // phpcs:ignore: Magento2.SQL.RawQuery.FoundRawSql
        $sql = "UPDATE $table SET `value` = $value WHERE " . join(' AND ', $where);
        return $sql;
    }
}
