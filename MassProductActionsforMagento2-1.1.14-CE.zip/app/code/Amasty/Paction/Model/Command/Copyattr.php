<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */

declare(strict_types=1);

namespace Amasty\Paction\Model\Command;

use Amasty\Paction\Helper\Data;
use Amasty\Paction\Model\CustomException;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;

class Copyattr extends \Amasty\Paction\Model\Command
{
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var ProductFactory
     */
    protected $productFactory;

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var AdapterInterface
     */
    protected $connection;
    /**
     * @var ProductRepositoryInterface
     */
    private $productRepository;

    public function __construct(
        Data $helper,
        ProductFactory $productFactory,
        ResourceConnection $resource,
        ProductRepositoryInterface $productRepository
    ) {
        parent::__construct();
        $this->helper = $helper;
        $this->productFactory = $productFactory;
        $this->resource = $resource;
        $this->connection = $resource->getConnection();
        $this->productRepository = $productRepository;

        $this->_type = 'copyattr';
        $this->_info = [
            'confirm_title' => __('Copy Attributes')->__toString(),
            'confirm_message' => __('Are you sure you want to copy attributes?')->__toString(),
            'type' => $this->_type,
            'label' => __('Copy Attributes')->__toString(),
            'fieldLabel' => __('From')->__toString(),
            'placeholder' => __('ID of product')->__toString()
        ];
    }

    public function execute(array $ids, int $storeId, string $val): Phrase
    {
        $fromId = (int)trim($val);

        try {
            $fromProduct = $this->productRepository->getById($fromId, false, $storeId);
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('Please provide a valid product ID'));
        }

        if (!$fromProduct->getId()) {
            throw new LocalizedException(__('Please provide a valid product ID'));
        }
        $fromId = $this->helper->convertEntityIdToRowIdIfNeed($fromId);

        if (isset($fromId[0])) {
            $fromId = (int)$fromId[0];
        }

        if (!$fromId) {
            throw new LocalizedException(__('Please provide a valid product ID'));
        }

        if (in_array($fromId, $ids)) {
            throw new LocalizedException(__('Please remove source product from the selected products'));
        }
        // check attributes
        $codes = $this->helper->getModuleConfig('general/attr', $storeId);

        if (!$codes) {
            throw new LocalizedException(__('Please set attribute codes in the module configuration'));
        }

        $config = [];
        $codes = explode(',', $codes);

        foreach ($codes as $code) {
            $code = trim($code);
            /** @var \Magento\Eav\Model\Entity\Attribute $attribute */
            $attribute = $fromProduct->getResource()->getAttribute($code);

            if (!$attribute || !$attribute->getId()) {
                $message = __(
                    'There is no product attribute with code `%1`, '
                    . 'please compare values in the module configuration with stores > attributes > product.',
                    $code
                );

                throw new LocalizedException($message);
            }

            if ($attribute->getIsUnique()) {
                $message = __(
                    'Attribute `%1` is unique and can not be copied. '
                    . 'Please remove the code in the module configuration.',
                    $code
                );

                throw new LocalizedException($message);
            }

            $type = $attribute->getBackendType();

            if ($type === \Magento\Eav\Model\Entity\Attribute\AbstractAttribute::TYPE_STATIC) {
                $message = __(
                    'Attribute `%1` is static and can not be copied. '
                    . 'Please remove the code in the module configuration.',
                    $code
                );

                throw new LocalizedException($message);
            }

            if (!isset($config[$type])) {
                $config[$type] = [];
            }

            $config[$type][] = $attribute->getId();
        }
        // we do not use store id as it is global action
        $this->copyData($fromId, $ids, $config);

        return __('Attributes have been successfully copied.');
    }

    protected function copyData(int $fromId, array $ids, array $config)
    {
        $entityIdName = $this->helper->getEntityNameDependOnEdition();

        foreach ($config as $type => $attributes) {
            if (!$attributes) {
                continue;
            }

            $table = $this->resource->getTableName('catalog_product_entity_' . $type);
            $fields = ['attribute_id', 'store_id', $entityIdName, 'value'];

            foreach ($ids as $id) {
                $data = $this->connection->select()
                    ->from(['t' => $table])
                    ->reset('columns')
                    ->columns(['attribute_id', 'store_id', new \Zend_Db_Expr($id), 'value'])
                    ->where("t.$entityIdName = ?", $fromId)
                    ->where('t.attribute_id IN(?)', $attributes);
                $this->connection->query(
                    $this->connection->insertFromSelect(
                        $data,
                        $table,
                        $fields,
                        AdapterInterface::INSERT_ON_DUPLICATE
                    )
                );
            }
        }

        return true;
    }
}
