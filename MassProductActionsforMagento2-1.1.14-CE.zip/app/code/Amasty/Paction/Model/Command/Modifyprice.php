<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */
namespace Amasty\Paction\Model\Command;

use Amasty\Paction\Helper\Data;
use Amasty\Paction\Model\Command;
use Magento\Catalog\Model\Product;
use Magento\Eav\Model\Config;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\ObjectManagerInterface;
use Magento\Store\Model\Store;
use Magento\Store\Model\StoreManagerInterface;

class Modifyprice extends Command
{
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var ObjectManagerInterface
     */
    protected $objectManager;

    /**
     * @var Config
     */
    protected $eavConfig;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var AdapterInterface
     */
    protected $connection;

    public function __construct(
        Data $helper,
        ObjectManagerInterface $objectManager,
        Config $eavConfig,
        StoreManagerInterface $storeManager,
        ResourceConnection $resource
    ) {
        $this->helper = $helper;
        $this->objectManager = $objectManager;
        $this->resource = $resource;
        $this->eavConfig = $eavConfig;
        $this->storeManager = $storeManager;
        $this->connection = $resource->getConnection();

        parent::__construct();

        $this->_type = 'modifyprice';
        $this->_info = [
            'confirm_title' => 'Update Price',
            'confirm_message' => 'Are you sure you want to update price?',
            'type' => $this->_type,
            'label' => 'Update Price',
            'fieldLabel' => 'By',
            'placeholder' => '+12.5, -12.5, +12.5%'
        ];
    }

    public function execute(array $ids, int $storeId, string $val)
    {
        if (!preg_match('/^[+-][0-9]+(\.[0-9]+)?%?$/', $val)) {
            throw new LocalizedException(__('Please provide the difference as +12.5, -12.5, +12.5% or -12.5%'));
        }
        $sign = substr($val, 0, 1);
        $val  = substr($val, 1);
        $percent = ('%' == substr($val, -1, 1));

        if ($percent) {
            $val = (float)substr($val, 0, -1);
        }
            
        if ($val < 0.00001) {
            throw new LocalizedException(__('Please provide a non empty difference'));
        }
        
        $attrCode = $this->_getAttrCode();
        $this->_updateAttribute(
            $attrCode,
            $ids,
            $storeId,
            [
                'sign' => $sign, 'val' => $val, 'percent' => $percent
            ]
        );
        
        return __('Total of %1 products(s) have been successfully updated', count($ids));
    }

    protected function _updateAttribute(string $attrCode, array $productIds, int $storeId, array $diff)
    {
        $attribute = $this->eavConfig->getAttribute(Product::ENTITY, $attrCode);
        $db = $this->connection;
        $table = $attribute->getBackend()->getTable();
        $entityIdName = $this->helper->getEntityNameDependOnEdition();

        $where = [
            $db->quoteInto($entityIdName . ' IN(?)', $productIds),
            $db->quoteInto('attribute_id=?', $attribute->getAttributeId()),
        ];
        
        /**
         * If we work in single store mode all values should be saved just
         * for default store id. In this case we clear all not default values
         */
        $defaultStoreId = Store::DEFAULT_STORE_ID;

        if ($this->storeManager->isSingleStoreMode()) {
            $db->delete($table, join(' AND ', array_merge($where, [
                $db->quoteInto('store_id <> ?', $defaultStoreId)
            ])));
        }
        
        $value = $diff['percent'] ? '`value` * ' . $diff['val'] . '/ 100' : $diff['val'];
        $value = '`value`' . $diff['sign'] . $value;

        if ('fixed' == $this->helper->getModuleConfig('general/round', $storeId)) {
            $fixed = $this->helper->getModuleConfig('general/fixed', $storeId);
            if (!empty($fixed)) {
                $fixed = floatval($fixed);
                $value = 'FLOOR(' . $value . ') + ' . $fixed;
            }
        } else { // math
            $value = 'ROUND(' . $value . ',2)'; // probably we will need change 2 to additional setting
        }

        $storeIds  = [];
        if ($attribute->isScopeStore()) {
            $where[] = $db->quoteInto('store_id = ?', $storeId);
            $storeIds[] = $storeId;
        } elseif ($attribute->isScopeWebsite() && $storeId != $defaultStoreId) {
            $storeIds = $this->storeManager->getStore($storeId)->getWebsite()->getStoreIds(true);
            $where[] = $db->quoteInto('store_id IN(?)', $storeIds);
        } else {
            $where[] = $db->quoteInto('store_id = ?', $defaultStoreId);
        }
        
        // in case of store-view or website scope we need to insert default values
        // first, to be able to update them.
        // @todo: Special price can be null in the base store
        if ($storeIds) {
            $cond = [
                $db->quoteInto('t.' . $entityIdName .' IN(?)', $productIds),
                $db->quoteInto('t.attribute_id=?', $attribute->getAttributeId()),
                't.store_id = ' . $defaultStoreId,
            ];
            foreach ($storeIds as $id) {
                // phpcs:ignore: Magento2.SQL.RawQuery.FoundRawSql
                $sql = "INSERT IGNORE INTO $table (`value_id`, `attribute_id`, `store_id`, `$entityIdName`, `value`) "
                     . " SELECT t.`value_id`, t.`attribute_id`, $id, t.`$entityIdName`, t.`value` FROM $table AS t"
                     . " WHERE " . join(' AND ', $cond)
                ;
                $db->query($sql);
            }
        }
        
        $sql = $this->_prepareQuery($table, $value, $where);
        $db->query($sql);
    }

    protected function _prepareQuery($table, $value, $where)
    {
        // phpcs:ignore: Magento2.SQL.RawQuery.FoundRawSql
        $sql = "UPDATE $table SET `value` = $value WHERE " . join(' AND ', $where);
        return $sql;
    }
    
    protected function _getAttrCode()
    {
        return 'price';
    }
}
