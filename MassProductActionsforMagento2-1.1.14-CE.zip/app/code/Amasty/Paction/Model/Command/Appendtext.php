<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */

declare(strict_types=1);

namespace Amasty\Paction\Model\Command;

use Amasty\Paction\Helper\Data;
use Magento\Catalog\Model\Product\Attribute\Repository as ProductAttributeRepository;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Phrase;

class Appendtext extends \Amasty\Paction\Model\Command
{
    const MODIFICATOR = '->';
    const FIELD = 'value';

    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var ResourceConnection
     */
    protected $resource;

    /**
     * @var ProductAttributeRepository
     */
    protected $productAttributeRepository;

    public function __construct(
        Data $helper,
        ResourceConnection $resource,
        ProductAttributeRepository $productAttributeRepository
    ) {
        parent::__construct();
        $this->helper = $helper;
        $this->resource = $resource;
        $this->productAttributeRepository = $productAttributeRepository;
        $this->_type = 'appendtext';
        $this->_info = [
            'confirm_title' => __('Append Text')->__toString(),
            'confirm_message' => __('Are you sure you want to append text?')->__toString(),
            'type' => $this->_type,
            'label' => __('Append Text')->__toString(),
            'fieldLabel' => __('Append')->__toString(),
            'placeholder' => __('attribute_code->text')->__toString()
        ];
    }

    public function execute(array $ids, int $storeId, string $val): Phrase
    {
        $appendRow = $this->generateAppend($val);
        $this->appendText($appendRow, $ids, $storeId);

        return __('Total of %1 products(s) have been successfully updated.', count($ids));
    }

    protected function generateAppend(string $inputText): array
    {
        $modificatorPosition = stripos($inputText, self::MODIFICATOR);

        if (false === $modificatorPosition) {
            throw new LocalizedException(__('Append field must contain: Attribute Code->Text to Append'));
        }

        $attributeCode = substr($inputText, 0, $modificatorPosition);
        $appendText = substr(
            $inputText,
            (strlen($attributeCode) + strlen(self::MODIFICATOR)),
            strlen($inputText)
        );
        $attributeCode = trim($attributeCode);

        return [$attributeCode, $appendText];
    }

    protected function appendText(array $searchReplace, array $ids, int $storeId)
    {
        list($attributeCode, $appendText) = $searchReplace;

        try {
            $attribute = $this->productAttributeRepository->get($attributeCode);
        } catch (NoSuchEntityException $e) {
            throw new LocalizedException(__('There is no product attribute with code `%1`, ', $attributeCode));
        }

        $connection = $this->resource->getConnection();
        $set = $this->addSetSql($connection->quote($appendText), $storeId, $attributeCode);
        $table = $this->resource->getTableName('catalog_product_entity');
        $entityIdName = $this->helper->getEntityNameDependOnEdition();
        $conditions[$entityIdName . ' IN (?)'] = $ids;

        if ($attribute->getBackendType() !== \Magento\Eav\Model\Entity\Attribute\AbstractAttribute::TYPE_STATIC) {
            $table = $this->resource->getTableName('catalog_product_entity_' . $attribute->getBackendType());
            $conditions['store_id = ?'] = $storeId;
            $conditions['attribute_id = ?'] = $attribute->getAttributeId();
        }

        $connection->update(
            $table,
            $set,
            $conditions
        );
    }

    protected function addSetSql(string $appendText, int $storeId, string $attributeCode): array
    {
        $field = $attributeCode == 'sku' ? 'sku' : self::FIELD;
        $position = $this->helper->getModuleConfig('general/append_text_position', $storeId);

        if ($position == \Amasty\Paction\Model\Source\Append::POSITION_BEFORE) {
            $firstPart = $appendText;
            $secondPart = $field;
        } else {
            $firstPart = $field;
            $secondPart = $appendText;
        }

        return [$field => new \Zend_Db_Expr(sprintf(' CONCAT(%s, %s)', $firstPart, $secondPart))];
    }
}
