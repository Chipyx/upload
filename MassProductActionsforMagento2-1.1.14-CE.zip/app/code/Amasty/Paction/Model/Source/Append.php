<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Paction
 */


namespace Amasty\Paction\Model\Source;

class Append implements \Magento\Framework\Option\ArrayInterface
{
    const POSITION_BEFORE = 'before';
    const POSITION_AFTER = 'after';

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::POSITION_BEFORE,
                'label' => __('Before Attribute Text')
            ],
            [
                'value' => self::POSITION_AFTER,
                'label' => __('After Attribute Text')
            ]
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            self::POSITION_BEFORE => __('Before Attribute Text'),
            self::POSITION_AFTER => __('After Attribute Text')
        ];
    }
}
